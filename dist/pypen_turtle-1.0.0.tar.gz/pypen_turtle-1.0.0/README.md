# Pydraw
_note: yes, I know my previous projects were vibe-coded, I am dissapointed of myself. BUTTTT I've decided to re-awaken my developer
powers and made this library. Yes. I build it. I didn't use AI at **all**_

Pydraw is an addition to the python's turtle library, adding shapes, polygons, and more.

there is nothing here....yet!